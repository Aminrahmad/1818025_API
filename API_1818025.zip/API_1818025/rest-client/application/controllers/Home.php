<?php 

class Home extends CI_Controller {
    public function index($nama = '1818025')
    {
        $data['judul'] = 'JERSEY BOLA';
        $data['nama'] = $nama;
        $this->load->view('templates/header', $data);
        $this->load->view('home/index', $data);
        $this->load->view('templates/footer');
    }
}