<?php

class Jersey extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Jersey_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['judul'] = 'Daftar Jersey';
        $data['tb_jersey'] = $this->Jersey_model->getAllJersey();
        if( $this->input->post('keyword') ) {
            $data['tb_jersey'] = $this->Jersey_model->cariDataJersey();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('jersey/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data Jersey';
        $this->form_validation->set_rules('id_jersey', 'ID Jersey', 'required');
        $this->form_validation->set_rules('nama_jersey', 'Nama Jersey', 'required');
        $this->form_validation->set_rules('ukuran', 'Ukuran', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');
        //$this->form_validation->set_rules('nrp', 'NRP', 'required|numeric');
        //$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('jersey/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->Jersey_model->tambahDataJersey();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('jersey');
        }
    }

    public function hapus($id_jersey)
    {
        $this->Jersey_model->hapusDataJersey($id_jersey);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('jersey');
    }

    public function detail($id_jersey)
    {
        $data['judul'] = 'Detail Data Jersey';
        $data['tb_jersey'] = $this->Jersey_model->getJerseyById($id_jersey);
        $this->load->view('templates/header', $data);
        $this->load->view('jersey/detail', $data);
        $this->load->view('templates/footer');
    }

    public function ubah($id_jersey)
    {
        $data['judul'] = 'Form Ubah Data Jersey';
        $data['tb_jersey'] = $this->Jersey_model->getJerseyById($id_jersey);
        //$data['jurusan'] = ['Teknik Informatika', 'Teknik Mesin', 'Teknik Planologi', 'Teknik Pangan', 'Teknik Lingkungan'];
        $this->form_validation->set_rules('nama_jersey', 'Nama Jersey', 'required');
        $this->form_validation->set_rules('ukuran', 'Ukuran', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required|numeric');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('jersey/ubah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Jersey_model->ubahDataJersey();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('jersey');
        }
    }

}
