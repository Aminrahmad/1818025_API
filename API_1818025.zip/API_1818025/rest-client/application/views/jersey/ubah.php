<div class="container">

    <div class="row mt-3">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Form Ubah Data Jersey
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <input type="hidden" name="id_jersey" value="<?= $tb_jersey['id_jersey']; ?>">
                        <div class="form-group">
                            <label for="nama_jersey">Nama Jersey</label>
                            <input type="text" name="nama_jersey" class="form-control" id="nama_jersey" value="<?= $tb_jersey['nama_jersey']; ?>">
                            <small class="form-text text-danger"><?= form_error('nama_jersey'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="ukuran">Ukuran</label>
                            <input type="text" name="ukuran" class="form-control" id="ukuran" value="<?= $tb_jersey['ukuran']; ?>">
                            <small class="form-text text-danger"><?= form_error('ukuran'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="text" name="harga" class="form-control" id="harga" value="<?= $tb_jersey['harga']; ?>">
                            <small class="form-text text-danger"><?= form_error('harga'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="stok">Stok</label>
                            <input type="text" name="stok" class="form-control" id="stok" value="<?= $tb_jersey['stok']; ?>">
                            <small class="form-text text-danger"><?= form_error('stok'); ?></small>
                        </div>
                        <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah Data</button>
                        <a href="<?= base_url(); ?>jersey" class="btn btn-primary ">Kembali</a>
                    </form>
                </div>
            </div>


        </div>
    </div>

</div>