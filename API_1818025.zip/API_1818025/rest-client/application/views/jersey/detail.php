<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">

            <div class="card">
                <div class="card-header">
                    Detail Data Jersey
                </div>
                <div class="card-body">
                    <h4 class="card-title">Nama Jersey : <?= $tb_jersey['nama_jersey']; ?></h4>
                    <p class="card-text">Ukuran : <?= $tb_jersey['ukuran']; ?></p>
                    <p class="card-text">Harga : <?= $tb_jersey['harga']; ?></p>
                    <p class="card-text">Stok : <?= $tb_jersey['stok']; ?></p>
                    <a href="<?= base_url(); ?>jersey" class="btn btn-primary">Kembali</a>
                </div>
            </div>
        
        </div>
    </div>
</div>