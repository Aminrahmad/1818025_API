<?php 
use GuzzleHttp\Client;

class Jersey_model extends CI_model {

    private $_client;

    public function __construct()
    {
        $this->_client = new Client([
            'base_uri' => 'http://localhost:8080/API_1818025/rest-server/index.php/',
            'auth' => ['amin','12345']
        ]);

    }

    public function getAllJersey()
    {
        //return $this->db->get('tb_jersey')->result_array();

        $response = $this->_client->request('GET', 'jersey', [
            'query' => [
                'wpu-key' => 'api_1818025'
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return $result['data'];
    }

    public function getJerseyById($id_jersey)
    {
        //return $this->db->get_where('tb_barang', ['id_jersey' => $id_jersey])->row_array();

        $response = $this->_client->request('GET', 'jersey', [
            'query' => [
                'wpu-key' => 'api_1818025',
                'id_jersey' => $id_jersey
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return $result['data'][0];

    }

    public function tambahDataJersey()
    {
        $data = [
            "id_jersey" => $this->input->post('id_jersey', true),
            "nama_jersey" => $this->input->post('nama_jersey', true),
            "ukuran" => $this->input->post('ukuran', true),
            "harga" => $this->input->post('harga', true),
            "stok" => $this->input->post('stok', true),
            'wpu-key' => 'api_1818025'
        ];

        //$this->db->insert('tb_jersey', $data);
        $response = $this->_client->request('POST', 'jersey', [
            'form_params' => $data
                
        ]);
        $result = json_decode($response->getBody()->getContents(), true);
        return $result;

    }

    public function hapusDataJersey($id_jersey)
    {
        // $this->db->where('id', $id);
        //$this->db->delete('tb_jersey', ['id_jersey' => $id_jersey]);
        $response = $this->_client->request('DELETE', 'jersey', [
            'form_params' => [
                
                'id_jersey' => $id_jersey,
                'wpu-key' => 'api_1818025'

            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);
        return $result;
    }


    public function ubahDataJersey()
    {
        $data = [
            "id_jersey" => $this->input->post('id_jersey', true),
            "nama_jersey" => $this->input->post('nama_jersey', true),
            "ukuran" => $this->input->post('ukuran', true),
            "harga" => $this->input->post('harga', true),
            "stok" => $this->input->post('stok', true),
            'wpu-key' => 'api_1818025'
        ];

        //$this->db->where('id_jersey', $this->input->post('id_jersey'));
        //$this->db->update('tb_jersey', $data);
        $response = $this->_client->request('PUT', 'jersey', [
            'form_params' => $data
                
        ]);
        $result = json_decode($response->getBody()->getContents(), true);
        return $result;

    }

    public function cariDataJersey()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('id_jersey', $keyword);
        $this->db->or_like('nama_jersey', $keyword);
        $this->db->or_like('ukuran', $keyword);
        $this->db->or_like('harga', $keyword);
        $this->db->or_like('stok', $keyword);
        return $this->db->get('tb_jersey')->result_array();
    }
}